# AI Challenge 2019 Python Client
## Setup instructions

It is recommended to use Pycharm (JetBtains)otherwise, follow the below instructions to run the client:

```cd``` to the directory you want to save and run the code
```
git clone https://github.com/SharifAIChallenge/AIC19-Client-Python
cd AIC19-Client-Python
python3 Controller.py
```





